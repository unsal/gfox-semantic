import React from "react";
import KVKKLayout from "./layout/";
import './kvkk.css';
// import watermark from "../assets/img/watermark.png"

const KVKK = () => (
  <KVKKLayout>
    {/* <Container text style={{ marginTop: "7em" }}>
      <Image src={watermark}  disabled />
    </Container> */}
    {null}
  </KVKKLayout>
);

export default KVKK;
